<template>
    <div>
        <HighScores />
    </div>
</template>

<script>
import HighScores from '@/components/HighScores.vue'

export default {
    name: 'HighScoreView',
    components: {
        HighScores
    }
}
</script>
